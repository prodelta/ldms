<?php
$db_host = "localhost"; //hostname
$db_user = "cscappapk_ldms"; // username
$db_password = "csc@ldms"; // password
$db_name = "cscappapk_ldmsdb"; //database name

$connect = mysqli_connect($db_host, $db_user, $db_password,$db_name);
$connect->query("SET NAMES 'utf8'");
$sql="SELECT * FROM `tbl_signup` WHERE `user_name`='Nagu' AND `password`='nagu123'";
	$result=mysqli_query($connect,$sql)or die("Query fail:".mysqli_error($connect));
if($result != null){
	while($row=mysqli_fetch_row($result)){
	     echo "Successfully executed    ".$row[1]."   ".$row[2];
    }
}else {
	  echo "Failed to execute"; 
}	
	mysqli_close($connect);

?>

