


<nav class="navbar" id="navbar">
 <div class="navbar-header">

 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" >
	 <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>

      </button>

    <h4 class="bodyheader"> </h4>
    </div>

	 <div class="navbar-collapse collapse" id="myNavbar" style="margin-right:50px" >
	 <ul class="nav navbar-nav navbar-right" >
	 <li><a href="<?php echo e(url('docreg')); ?>">Documents Reg</a></li>
  <li><a href="<?php echo e(url('foreign')); ?>">Foreign Nationals</a></li>
  <li><a href="<?php echo e(url('director')); ?>">Directors Master</a></li>
  <li><a href="<?php echo e(url('insurance')); ?>">Insurance Master</a></li>
  <li><a href="<?php echo e(url('alerts')); ?>">Notifications</a></li>

 </ul>
  </div>
</nav>

<!-- <br>
<div class="links">
    <a href="<?php echo e(url('docreg')); ?>">Documents Reg</a>
    <a href="<?php echo e(url('foreign')); ?>">Foreign Nationals</a>
    <a href="<?php echo e(url('director')); ?>">Directors Master</a>
    <a href="<?php echo e(url('alerts')); ?>">Notifications</a>

</div>
<br> -->
