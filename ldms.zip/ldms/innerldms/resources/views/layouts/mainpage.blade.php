@extends('welcome')

@include('includes.nav')
